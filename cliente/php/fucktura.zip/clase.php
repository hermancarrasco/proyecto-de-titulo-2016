<?php
class BaseDeDatos{

	private $ser;
	private $usu;
	private $pas;
	private $bd;
	private $id_bd;
	private $id_con;




	
	function conectarBD(){
			$this->ser="localhost"; //servidor
			$this->usu="root"; //usuario
			$this->pas=""; //contraseña
			$this->bd="proyecto"; //base de datos
			
			$this->id_con=mysql_connect($this->ser,$this->usu,$this->pas); //cineccion a la BD
			if(!$this->id_con){
				die("Error en la conexion con la BD");
			}
			$this->id_bd=mysql_select_db($this->bd,$this->id_con); //Seleccion de la BD
			if(!$this->id_bd){
				die("Error en la seleccion de la BD");
			}
			mysql_set_charset('utf8');
		}
		function desconectarBD(){
			mysql_close($this->id_con);
		}

		function imprimirComprobante($id,$dir,$tipo)
		{
			$sql="SELECT * FROM `gas_datosusuario` WHERE `id_user`=$id";
			$sentencia=mysql_query($sql,$this->id_con);
			$rut="";$nombre="";$apellido="";$telefono="";$celular="";
			while($rs=mysql_fetch_array($sentencia,MYSQL_BOTH)){
				$rut=$rs["rut"];
				$nombre=$rs["first_name"];
				$apellido=$rs["last_name"];
				$telefono=$rs["telefono"];
				$celular=$rs["celular"];
				
			}
			$sql2="SELECT * FROM `gas_producto` WHERE carga='$tipo'";
			$sentencia2=mysql_query($sql2,$this->id_con);
			$gasId="";$gasNombre="";$gasPrecio="";
			while($rs=mysql_fetch_array($sentencia2,MYSQL_BOTH)){
				$gasId=$rs["id_producto"];
				$gasNombre=$rs["nombre_producto"];
				$gasPrecio=$rs["precio"];
			}
			date_default_timezone_set("America/Santiago");//metodo para que la hora sea la de Chile
			
			$sql="SELECT * FROM `gas_ventas` where `id_user`=$id order by `id_venta` desc limit 1";
			$sentencia=mysql_query($sql,$this->id_con);
			$numeroVenta=0;
			while ($rs=mysql_fetch_array($sentencia,MYSQL_BOTH)) {
				$numeroVenta=$rs["id_venta"];
			}
			$numeroVenta+=1;
			echo "<div id='contenidocbt' name='contenidocbt'>";
			echo"<div id='superior'>";
			echo"<div id='superior_izq'>";
			echo"<table>";
			echo"<tr>";
			echo"<td>";
			echo '<img src="../img/lipi.jpg" width="140" height="140" align="middle">';
			echo"</td>";
			echo"<td>";
			echo"<p id='titulo_izq'>GLPExpress.<p>";
			echo"<p id='giros'>Giro: <br/>";
			echo"	<br/>";
			echo"	<br/>";
			echo"	<br/></p>";
			echo"<p id='direccion'>, Rancagua</p>";
			echo"</td>";
			echo"</tr>";
			echo"</table>"; 
			echo"</div>";
			echo"<div id='superior_der'>";
			echo"<center><p id='cuadro_der'> COMPROBANTE DE VENTA Nº ".$numeroVenta."<br/><br/><br/>";
			echo"GLPExpress</p><br/></center>";
			echo"</div>";
			echo"</div>";
			echo"<div id='centro_informacion'>";
			echo"<div id='intermedio_detalle'>";
			echo"<center><p id='estilo_detalle'>DETALLE </p></center>";
			echo"<center>";
			echo "<r1 id='subtitulo'>Fecha de emision de comprobante: </r1>";
			echo date("d-m-Y");
			echo "<br/><r1 id='subtitulo'>Hora: </r1>";
			echo date("H:i:s");
			echo"</center>";
			echo"<br/>____________________________________________<br/>";
			echo "<r1 id='subtitulo'>Rut: </r1>".$rut."<br/>";
			echo "<r1 id='subtitulo'>Nombre: </r1>".$nombre." ".$apellido."<br/>";
			echo "<r1 id='subtitulo'>Dirección: </r1>".$dir."<br/>";
			echo "<r1 id='subtitulo'>Telefono: </r1>".$telefono."<br/>";
			echo "<r1 id='subtitulo'>Celular: </r1>".$celular."<br/>";
			echo"____________________________________________<br/>";
			echo "<r1 id='subtitulo'>Tipo de Cilindro: </r1>".$gasNombre."<br/>";
			echo "<r1 id='subtitulo'>Total a Pagar: </r1>$".$gasPrecio."<br/><br/>";
			echo "<r1 id='subtitulo'>Forma de pago: </r1> Efectivo<br/>";		
			echo "<r1 id='subtitulo2'>Estado: </r1>Vigente<br/><br/>";
			echo "<r1 id='subtitulo'>Atendido por: </r1> Mister Master<br/><br/>";
			echo"</div>";
			
			echo "<center>Documento no valido como boleta, Recuerde solicitarla en el Local</center><br/>";
			echo "<center><p id='estilo_detalle'>GRACIAS SU PREFERENCIA!</p></center> ";
			echo"</div>";			
			echo"</div>";
		}
		/***** Cierre Generar comprobante *****/

		function direccion($id,$tipo)
		{

			$sql="SELECT * FROM `gas_direcciones` WHERE `id_usuario`=$id";
			$sentencia=mysql_query($sql,$this->id_con);
			echo '<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
			<div class="panel panel-default">
			<div class="panel-heading" role="tab" id="headingOne">
			<h4 class="panel-title">
			<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne'.$tipo.'" aria-expanded="true" aria-controls="collapseOne'.$tipo.'">
			Dirección ya registrada
			</a>
			</h4>
			</div>
			<div id="collapseOne'.$tipo.'" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
			<div class="panel-body">
			<select name="" id="cboDireccion'.$tipo.'" class="form-control" required="required">';
			while($rs=mysql_fetch_array($sentencia,MYSQL_BOTH)){
				
				if ($rs["calle"]!="") {
					echo '<option value="'.$rs["calle"].' '.$rs["numero"].'">'.$rs["calle"].' '.$rs["numero"].'</option>';
				}else{
				echo '<option value="'.$rs["direccion"].'">'.$rs["direccion"].'</option>';
				}
			}
			echo '</select>	

			</div>
			<div class="form-group">

			<a class="btn btn-primary" data-toggle="modal" id="btnDireccionRegistrada" href="#modalConfirmar" onclick="datosPedido('.$tipo.')">Confirmar Pedido</a>
			</div>  
			</div>
			</div>

			<div class="panel panel-default">
			<div class="panel-heading" role="tab" id="headingTwo">
			<h4 class="panel-title">
			<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo'.$tipo.'" aria-expanded="false" aria-controls="collapseTwo'.$tipo.'">
			Dirección nueva
			</a>
			</h4>
			</div>
			<div id="collapseTwo'.$tipo.'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
			<div class="panel-body text-center">

			<form action="" method="POST" role="form">
			<legend>Busque su Direccion</legend>
			<div class="form-inline">
			<div class="form-group  has-feedback">
			<label class="control-label" for="inputWarning2">Ingrese dirección nueva</label>
			<input type="text" class="form-control" id="direccion'.$tipo.'" placeholder="Av España 1500, Rancagua" aria-describedby="inputWarning2Status">
			
			<span class="glyphicon glyphicon-search form-control-feedback" aria-hidden="true"></span>
			<span id="inputWarning2Status" class="sr-only">(warning)</span>
			</div>
			<button type="button" class="btn btn-primary" id="btnBuscar" onclick="buscarGeo('.$tipo.')">Buscar Dirección</button>
			</div>
			<p id="cargando" style="display:none">Cargando...</p>
			<div class="text-center" style="width:100%; height: 500px;margin: 0;padding: 0;text-align:center;">
			<div id="mapa'.$tipo.'" style="height: 100%;">
			
			</div>
			</div>

			</div>		
			<a class="btn btn-primary" data-toggle="modal" id="btnDireccionNueva" href="#modalConfirmar" onclick="datosPedidoNewDir('.$tipo.')">Confirmar Pedido</a>	
			</form>

			</div>
			</div>
			</div>

			</div>';
		}
		/****  Cierre direccion del cliente  ****/
		function venta($idUsuario,$gasTipo,$dirUsuario){
	date_default_timezone_set("America/Santiago");//metodo para que la hora sea la de Chile
	$time = time();
	$sql3="";
			//busca el precio en la bd por si las moscas
	$sql="SELECT * FROM `gas_producto` WHERE `carga`=$gasTipo";
	$sentencia=mysql_query($sql,$this->id_con);
	while ($rs=mysql_fetch_array($sentencia,MYSQL_BOTH)) {

		$sql2="INSERT INTO `proyecto`.`gas_ventas` (`id_venta`, `id_prod`, `id_user`, `precio_venta`, `fecha_venta`, `hora`,`entregado`,`pagado`) VALUES (NULL, '".$rs["id_producto"]."', '$idUsuario', '".$rs["precio"]."', '".date("Y-m-d (H:i:s)", $time)."','".date("H:i:s")."',0,0);";
		$sentencia2=mysql_query($sql2,$this->id_con);
		echo "mensaje de prueba";			
	}
}/****  Cierre del ingreso de las ventas  ****/	

/****  Registra una nueva direccion del cliente  ****/
	function nuevaDireccion($dir,$id)
	{
		$sql="INSERT INTO `proyecto`.`gas_direcciones` (`id_direcciones`, `latitud`, `longitud`, `calle`, `numero`, `direccion`, `estado`, `id_usuario`) VALUES (NULL, NULL, NULL, NULL, NULL, '$dir', '1', '$id');";
		$sentencia=mysql_query($sql,$this->id_con);
		echo "Se registro la direccion";

	}
/****    ****/
/****    ****/
/****    ****/
}//cierre BD
?>
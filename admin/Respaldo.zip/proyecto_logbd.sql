-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 04-12-2014 a las 20:03:49
-- Versión del servidor: 5.6.12-log
-- Versión de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `proyecto_logbd`
--
CREATE DATABASE IF NOT EXISTS `proyecto_logbd` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `proyecto_logbd`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_respaldos`
--

CREATE TABLE IF NOT EXISTS `config_respaldos` (
  `Codigo` int(3) NOT NULL AUTO_INCREMENT COMMENT 'Codigo de Tabla',
  `Frecuencia` varchar(20) NOT NULL COMMENT 'Modo de Respaldo',
  `Dia` int(1) NOT NULL COMMENT 'El dia especifico configurado',
  `Hora` varchar(5) NOT NULL COMMENT 'Hora del respaldo',
  PRIMARY KEY (`Codigo`),
  KEY `Codigo` (`Codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Esta tabla almacena la configuración del respaldo automatico' AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `config_respaldos`
--

INSERT INTO `config_respaldos` (`Codigo`, `Frecuencia`, `Dia`, `Hora`) VALUES
(1, 'DIARIO', 0, '03:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `emergencias`
--

CREATE TABLE IF NOT EXISTS `emergencias` (
  `codigo` int(1) NOT NULL COMMENT 'Identificador',
  `estado` varchar(15) NOT NULL COMMENT 'estado de emergencia',
  `motivo` text NOT NULL COMMENT 'razon del hecho',
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='tabla que almacena el estado de emergencia temporal en la organizacion';

--
-- Volcado de datos para la tabla `emergencias`
--

INSERT INTO `emergencias` (`codigo`, `estado`, `motivo`) VALUES
(1, 'Desactiva', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros_respaldos`
--

CREATE TABLE IF NOT EXISTS `registros_respaldos` (
  `codigo` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Codigo del registro',
  `fecha` date NOT NULL COMMENT 'Fecha del suceso',
  `hora` time NOT NULL COMMENT 'Hora del suceso',
  `responsable` varchar(12) NOT NULL COMMENT 'Quien provoco el suceso',
  `nombre_resp` varchar(50) NOT NULL COMMENT 'nombre de la persona que provoco el evento',
  `motivo` varchar(50) NOT NULL COMMENT 'motivo del suceso',
  `observacion` varchar(5000) NOT NULL COMMENT 'observaciones sobre el suceso',
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Almacena a modo de log las acciones realizadas con la base de datos principal' AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `registros_respaldos`
--

INSERT INTO `registros_respaldos` (`codigo`, `fecha`, `hora`, `responsable`, `nombre_resp`, `motivo`, `observacion`) VALUES
(1, '2014-11-09', '13:12:32', '18.374.194-2', 'Victor Riveros', 'GENERACION RESPALDO MANUAL', 'Auto -- Segun fecha y hora registrada se crea un nuevo respaldo manual'),
(2, '2014-12-04', '17:00:07', '18.374.194-2', 'Victor Riveros', 'GENERACION RESPALDO MANUAL', 'Auto -- Segun fecha y hora registrada se crea un nuevo respaldo manual');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_sesiones`
--

CREATE TABLE IF NOT EXISTS `registro_sesiones` (
  `id` int(255) NOT NULL AUTO_INCREMENT COMMENT 'identificador del acceso',
  `usuario` varchar(100) NOT NULL COMMENT 'rut-nombre de la sesion',
  `tipo_sesion` varchar(30) NOT NULL COMMENT 'tipo de sesion iniciada',
  `fecha` date NOT NULL COMMENT 'fecha del inicio de sesion',
  `hora` time NOT NULL COMMENT 'hora del inicio de sesion',
  `ip` varchar(15) NOT NULL COMMENT 'direccion ip desde la cual se esta ingresando',
  `navegador` varchar(50) NOT NULL COMMENT 'navegador del usuario',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='tabla que almacena el registro de inicio de sesiones' AUTO_INCREMENT=16 ;

--
-- Volcado de datos para la tabla `registro_sesiones`
--

INSERT INTO `registro_sesiones` (`id`, `usuario`, `tipo_sesion`, `fecha`, `hora`, `ip`, `navegador`) VALUES
(1, '18.374.194-2 / Victor Riveros', 'admin', '2014-11-20', '21:07:36', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(2, '18.374.194-2 / Victor Riveros', 'admin', '2014-11-20', '21:14:48', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(3, '14.439.463-1 / Maria Fernandez', 'cliente', '2014-11-20', '22:18:07', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(4, '18.374.194-2 / Victor Riveros', 'admin', '2014-11-20', '22:51:05', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(5, '14.439.463-1 / Maria Fernandez', 'cliente', '2014-11-20', '22:52:28', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(6, '18.374.194-2 / Victor Riveros', 'admin', '2014-11-20', '23:06:29', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(7, '88.888.888-8 / Juana Perez', 'rece', '2014-11-21', '00:21:31', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(8, '18.374.194-2 / Victor Riveros', 'admin', '2014-11-21', '00:33:05', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(9, '18.374.194-2 / Victor Riveros', 'admin', '2014-12-01', '23:20:13', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(10, '18.374.194-2 / Victor Riveros', 'admin', '2014-12-04', '03:25:17', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(11, '18.374.194-2 / Victor Riveros', 'admin', '2014-12-04', '16:28:18', '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(12, '18.042.997-2 / Bastian Orellana', 'admin', '2014-12-04', '16:43:11', '186.9.9.39', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/53'),
(13, '14.439.463-1 / Eduardo Tapia', 'cliente', '2014-12-04', '16:46:24', '172.16.0.1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(14, '18.374.194-2 / Victor Riveros', 'admin', '2014-12-04', '16:48:38', '172.16.0.1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko'),
(15, '88.888.888-8 / Juana Perez', 'rece', '2014-12-04', '17:01:58', '172.16.0.1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

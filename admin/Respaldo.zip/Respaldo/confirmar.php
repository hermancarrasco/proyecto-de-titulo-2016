<?php 
require_once("clase_logbd.php");
    $c= new BaseDeDatos();
    $c->conectarBD();


if (isset($_POST["btnRestaurar"])) {
	$archivo=$_POST["archivo"];
	$ser="localhost";
	$usu="root";
	$pas="";
	$dropbd = 'DROP DATABASE proyecto;';
	$crearbd = 'CREATE DATABASE proyecto;';
	$seleccionarbd='use proyecto;';
	$con=mysql_connect($ser,$usu,$pas);
	mysql_query($dropbd,$con);
	mysql_query($crearbd,$con);
	mysql_query($seleccionarbd,$con);
	/***  Verificar si el sistema operativo es windows  ***/
	if (strtoupper(substr(PHP_OS, 0,3))==='WIN') {		
		$destino="C:/resp/".$archivo;
		$dbname="proyecto";
		$executa ="C:/xampp/mysql/bin/mysql -u $usu  $dbname < $destino";   

	}else{    	
		$destino="/Users/herman/Desktop/respaldo/".$archivo;
		$dbname="proyecto";
		$executa ="/Applications/XAMPP/bin/mysql -u $usu  $dbname < $destino"; 
	}

	system($executa,$resultado); 

	if ($resultado){  
		echo "ERROR, NO SE PUDO COMPLETAR LA RESTAURACION";
	}else{ 
		echo "RESTAURACION EXITOSA DE LA BASE DE DATOS";
		
	}
}//cierre restauracion de la bd manual

if (isset($_POST["respaldoManual"])) {
	date_default_timezone_set('America/Santiago');
            $fechahora=date("Ymd-Hi");
            $executa = "C:/xampp/mysql/bin/mysqldump -u root proyecto > c:/resp/".$fechahora."_BD_Proyecto.sql";
            system($executa, $resultado);


        if ($resultado) {
           echo "Error al respaldar la base de datos";

        } else {
            echo "Se genero correctamente el respaldo de la base de datos";

        }


}//cierre respaldo manual de la bd

if (isset($_POST["cargaConfActualRespAuto"])) {
	$c->cargaConfActualRespAuto();
}

if (isset($_POST["btnConfAuto"])) {
	$frecuencia=$_POST["frecuencia"];
	$dia=$_POST["dia"];
	$hora=$_POST["hora"];
	
	$c->configurarRespAuto($frecuencia,$dia,$hora);
}


?>